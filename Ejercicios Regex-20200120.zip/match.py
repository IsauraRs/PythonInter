import re

if re.match("hola", "hola"):
	print("Hizo match")

if re.match(".ola", "tola"):
	print("Hizo match")

if re.match("\.ola", ".ola"):
	print("Hizo match")

if re.match("python|jython|cython", "cython"):
	print("Hizo match")

if re.match("(p|j|c)ython", "python"):
	print("Hizo match")

if re.match("[pjc]ython", "cython"):
	print("Hizo match")

if re.match("niñ(o|a)s", "niños"):
	print("Hizo match")	

if re.match("cadena[0-9]","cadena1"):
	print("Hizo match")	

# [0-9] 0..9
# [a-z] a, b, c, d, ..., z
# [A-Z] A, B, C, D, ..., Z
# [0-9a-zA-Z]
# [a-f5-8]
# [az-]
# [.-.]
# [\.-]
# Cuantificadores
# +, *, ?, {}
# + al menos una vez
# * cero o mas veces 
# ? puede o no estar 0 o 1
# {n} n = numero de veces exactas

if re.match("python+", "pythonnn"):
	print("Hizo match")

if re.match("python*", "pytho"):
	print("Hizo match")	

if re.match("python?", "pytho"):
	print("Hizo match")

if re.match("python{3,8}", "pythonnnn"):
	print("Hizo match")

# .* cualquier cadena, de cualquier largo
# [a-z]{3,6} -> cvb,cvbg,fghjjl
# .*hola
# ? -> asdsdasdasdhola!, asdasdhola, hola
# b+? -> b
# (ab)+ ab, abab, ababab

# ^ debe ir al principio de la cadena
# $ debe ir al final de la cadena

if re.match("^http", "http://google.com"):
	print("Hizo match")

if re.match("http$", "://google.comhttp"):
	print("Hizo match")

if re.match("\Aa[0-9].*(end|fin)$", "a8sdfsdfsdfin"):
	print("Hizo match")

if re.search("\Aa[0-9].*(end|fin)$", "a2 dfsdfs fsdf fin"):
	print("Hizo match")	

#Para que no sea sensible a mayusculas y minusculas
if re.match("python[^0-9a-z]", "pythonZ", re.IGNORECASE):
	print("Hizo match")
