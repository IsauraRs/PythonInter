import re

asistentes = ['Karina Flores', 'Alejandro Herrera', 'Hector Cabello','Beatriz Flores']

for i in asistentes:
	#Buscamos en la lista através de una expresión regular
	if re.findall('Flores$',i):
		print(i)
	else:
		print("No hubo coincidencias")