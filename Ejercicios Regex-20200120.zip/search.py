#Modulo para trabajar con regex solo para cadenas de texto
import re
#cadena en donde se buscara
texto = "El día de hoy aprenderemos expresiones regulares en python 3. Porque python es cool y se hace notar ;)"
#lo que queremos encontrar
cadena = "expresiones regulares"
#search regresa un objeto de tipo Match
print(re.search(cadena,texto))
