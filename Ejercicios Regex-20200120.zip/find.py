#Creando nuestra propia excepción
class MatchError(Exception):
	#Metodo mágico str
	def __str__(self):
		print("Cantidad de match insuficientes ")
#Modulo para trabajar con regex solo para cadenas de texto
import re
#cadena en donde se buscara
texto = "El día de hoy aprenderemos expresiones regulares en python 3. Porque python es cool y se hace notar ;)"
#lo que queremos encontrar
cadena = "python"

#Muestra todas las coincidencias en una lista
print(re.findall(cadena,texto))
#Obtenemos el tamaño de la lista
tamanio = len(re.findall(cadena,texto))
#Evaluamos el tamaño de la lista
if tamanio < 4:
	#Lanzamos la excepción
	raise MatchError()
	exit()
else:
	print("Cantidad de match suficientes") 