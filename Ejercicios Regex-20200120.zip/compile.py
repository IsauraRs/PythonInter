#Programa para encontrar coincidencias en una url
import re
#La regex se compila y se convierte en un objeto que posee metodos
patron = re.compile("http?:\/\/[\w\-]+(\.[\w\-]+)+[/#?]?.*")
url = "^http://moodletest.proteco.mx$"

print(patron.findall(url))
#El objeto patron tiene los metodos, search,findall y match
if patron.search(url) is not None:
	print("Hizo match")