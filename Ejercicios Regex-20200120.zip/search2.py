#Modulo para trabajar con regex solo para cadenas de texto
import re
#cadena en donde se buscara
texto = "El día de hoy aprenderemos expresiones regulares en python 3. Porque python es cool y se hace notar ;)"
#lo que queremos encontrar
cadena = "expresiones regulares"

isMatch = re.search(cadena,texto)
if isMatch is not None:
	print("Hizo match ")
	#Indica apartir de que caracter de la linea se hizo el match
	print("El match inicia en ", isMatch.start())
	print("El match termina en ", isMatch.end())
	#Lo mismo de arriba pero en una tupla
	print("El match se hizo en ", isMatch.span())
	#Devuelve lo que encontro
	print("El match fue ", isMatch.group())
else:
	print("No hubo match")