#Solicitar que ingresen 2 números para que se sumen
#No se permitira que se ejecute nada mientras no se ingresen enteros
bandera = 0
while bandera==0:
	try:
		x = int(input("Inserte un numero: "))
		y = int(input("Inserte otro numero: "))
		bandera=1
		z =x+y

	except ValueError:
		print("Error, debes ingresar un numero entero")
	else:
		print(z)

