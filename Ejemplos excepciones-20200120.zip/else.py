#Try-except-else-finally
try:
	x = int(input("Inserte un numero: "))
	y = 10/x
	print("La division es:")

except ZeroDivisionError:
	print("Error, la division entre cero no esta definida")
except ValueError:
	print("Error, debes ingresar un numero")
else:
	print(y)
finally:
	print("Esto siempre se ejecuta")
print("Adios")