lista =[1,2,3,4]
#print(lista[2])
#lista.add

#AtributeErrpr
try:
	x=1
	x.atributo=10

except AttributeError:
	print("X no tiene atributos")

#IndexError
try:
	print(lista[4])
except IndexError:
	print("No existe el indice 4")

#KeyError
dic ={1:"hola",2:"adios"}
try: #Parte del codigo donde espero que suceda algun error
	print(dic[3])
except KeyError:
	print("No existe esa llave en el diccionario")




