#Ejemplo de una excepción utilizando el bloque finally
def division(x,y):
	try:
		resultado = x/y
	except ZeroDivisionError:
		print("La división entre cero no está definida")
	else:
		print("Resultado: ", resultado)
	finally:
		print("Se ejecuto el finally")

print("***Intento 1***")
division(9,3)
print("***Intento 2***")
division(9,0)
print("***Intento 3***")
division("8","2")