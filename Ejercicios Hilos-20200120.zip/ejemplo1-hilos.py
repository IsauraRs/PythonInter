import time
import datetime
import threading
vmax_hilos = {}
i = 0
def contador():
	global vmax_hilos
	global i
	i += 1
	nombre = threading.current_thread().getName()
	print("Soy el hilo ",nombre)
	lista = []
	for i in range(1,101):
		lista.append(i)
		#print(i)
	vmax_hilos[nombre] = i
	"""
	if threading.active_count()==1:
		print(vmax_hilos)
		print(threading.enumerate())
	"""
	time.sleep(5)
	return lista
def contador1():
	lista = []
	for i in range(100,201):
		lista.append(i)
		#print(i)
	return lista

def sumador(lista1,lista2):
	res = []
	print(lista2)
	for i in range(0,100):
		suma = lista1[i]+lista2[i]
		res.append(suma)
		print(res[i])

tiempo_ini = datetime.datetime.now()
hilo1=threading.Thread(target=contador)
hilo2=threading.Thread(target=contador)
hilo3=threading.Thread(target=sumador, kwargs={"lista1":contador(), "lista2":contador()})
hilo1.start()
hilo2.start()
#hilo1.join()
#hilo2.join()
hilo3.start()
hilo3.join()

tiempo_fin = datetime.datetime.now()
print("Tiempo transcurrido "+str(tiempo_fin.second-tiempo_ini.second))
print("Termino el programa")

