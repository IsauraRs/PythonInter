import threading

def funcion():
	print('Hola')

hilos = []
for in in range(11):
	hilos.append(threading.Thread(target = funcion))
	hilos[i].start()
