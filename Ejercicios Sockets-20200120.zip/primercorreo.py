import smtplib
 
to = "stephanie.proteco@gmail.com"
gmail_user = "stephescsan@gmail.com"
gmail_pwd = "Ztephaniitha1"
smtpserver = smtplib.SMTP("smtp.gmail.com",587)

smtpserver.starttls() ## empieza conexión tls

smtpserver.login(gmail_user, gmail_pwd)
header = 'To:' + to + '\n' + 'From: ' + gmail_user + '\n' + 'Subject:Pruebas smtp \n'
print(header)
msg = header + '\n Hola como estas?\n'
print(smtpserver.sendmail(gmail_user, to, msg)) 
print ('hecho')
smtpserver.close()